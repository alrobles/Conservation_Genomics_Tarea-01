populations_haplotypes <- read_tsv("stacks/taller2/ref_map/results/03_populations/populations.haplotypes.tsv")

populations_haplotypes %>% select(bPon048) %>% filter(bPon048 == "consensus")

populations_haplotypes_gather <-   populations_haplotypes %>%
  select(-Cnt) %>% 
  gather(sample, value, -`# Catalog Locus ID`) %>% 
  filter(value == "consensus") %>% 
  janitor::clean_names()

populations_haplotypes_gather %>% 
  ggplot() + geom_point(aes(number_catalog_locus_id , cnt))

populations_haplotypes %>% janitor::clean_names() %>% 
  select(number_catalog_locus_id , cnt) %>% slice(1:100) %>% 
  ggplot() + geom_point(aes(number_catalog_locus_id , cnt))

populations_haplotypes_gather %>% 
  filter(sample == "bPon048") %>% 
  group_by(sample) %>% 
  mutate(id_sample = row_number()) %>% 
  ggplot() +
  geom_point(aes(x = id_sample, y = number_catalog_locus_id ))

populations_haplotypes_gather %>% 
  filter(sample == "bPon048") %>% 
  group_by(sample) %>% 
  mutate(id_sample = row_number()) %>% 
  ggplot() +
    geom_bar(aes(x = id_sample, y = number_catalog_locus_id ))
populations_haplotypes_gather_plot <- populations_haplotypes_gather %>% 
  filter(sample == "bPon048") %>% 
  group_by(sample) %>% 
  mutate(id_sample = row_number()) %>% 
  ggplot(aes(x=id_sample, y=number_catalog_locus_id, color = "sample")) +
  geom_bar(stat="identity", width=0.5) + facet_grid(sample ~ .)

png("results/populations_haplotypes.png", width = 960, height = 640)
populations_haplotypes_gather_plot
dev.off()
populations_haplotypes_gather %>% 
distinct(sample)

populations_haplotypes_gather %>% 
  filter(sample %in% c("bPon048", "bPon078")) %>% 
  ggplot(aes(x=number_catalog_locus_id, y = sample, color = sample)) +
  geom_point() 


read_tsv("stacks/taller2/ref_map/info/barcodes_lane1.txt", col_names = FALSE)


pop_map_25_smp <- read_tsv("stacks/taller2/ref_map/info/pop_map_25smp.txt", col_names = FALSE) %>% 
  rename(sample = X1, location = X2)

populations_haplotypes_gather %>% 
  left_join(pop_map_25_smp) %>% distinct(location)

populations_haplotypes_gather %>% 
  left_join(pop_map_25_smp) %>% 
  #filter(sample %in% c("bPon048", "bPon078")) %>% 
  ggplot(aes(x=number_catalog_locus_id, y = sample,  fill = location)) +
  geom_bar(stat="identity", width=0.5) + 
  theme_classic() + 
  ylab("population") + 
  xlab("Number Catalog locus id")+
  ggtitle( "Population  vs. locus id grouped by location")

