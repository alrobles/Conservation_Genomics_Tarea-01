#!/bin/bash
src=$HOME//conservationGenomics/stacks/taller2/ref_map

files="
Lco012
bLco02
bLco020
bLco021
bLco024
bLco027
bLco030
bLco031
bLco038
bLco09
bLco302
bLco312
bLco313
bLco315
bLco316
bLco320
bPon_461
bPon020
bPon048
bPon078
bPon084
bPon085
bPon167
bPon320
bPon338
bPon344
bPon353
bPon367
bPon376
bPon377
bPon392
bPon393
bPon404
bPon406
bPon409
bPon423
bPon430
bPon441
bPon446
bPon453
bPon460
bPon461
bPon477
F12
F14
F30
F348
F398400
F415
F427
F429
"
for sample in $files
do 
    bwa mem -t 8 assembly_scaffolds.fasta $src/samples_output/${sample}.fq.gz |
      samtools view -b |
      samtools sort --threads 4 > $src/aligned/${sample}.bam
done

